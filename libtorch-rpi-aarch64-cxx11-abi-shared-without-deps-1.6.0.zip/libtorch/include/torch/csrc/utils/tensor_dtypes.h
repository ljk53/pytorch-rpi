#pragma once

#include <tuple>
#include <string>
#include <ATen/ATen.h>

namespace torch { namespace utils {

void initializeDtypes();

}} // namespace torch::utils
