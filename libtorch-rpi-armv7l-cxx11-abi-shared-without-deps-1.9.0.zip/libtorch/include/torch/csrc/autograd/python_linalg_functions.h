#pragma once

namespace torch { namespace autograd {

void initLinalgFunctions(PyObject* module);

}} // namespace torch::autograd
