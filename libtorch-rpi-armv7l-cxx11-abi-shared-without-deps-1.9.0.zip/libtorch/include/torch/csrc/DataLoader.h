#pragma once

#include <torch/csrc/python_headers.h>

// NOLINTNEXTLINE(cppcoreguidelines-avoid-c-arrays,cppcoreguidelines-avoid-non-const-global-variables,modernize-avoid-c-arrays)
extern PyMethodDef DataLoaderMethods[];
