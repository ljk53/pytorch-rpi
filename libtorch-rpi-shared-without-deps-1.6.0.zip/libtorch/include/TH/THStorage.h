#pragma once
#include <TH/THStorageFunctions.h>

// Compatibility header. Use THStorageFunctions.h instead if you need this.
